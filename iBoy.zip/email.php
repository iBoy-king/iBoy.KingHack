<!-- REEDIT BY KEVIN GANS-->
<?php
$emailku = 'irvanadit97@gmail.com';//GANTI EMAIL LU DISINI.
?>